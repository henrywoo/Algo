#include <iostream>
#include <iterator>
#include "bst.h"
#include "list.h"

using namespace std;

int main(int argc,char* argv[]){
	//bst::test();
	dclist dl;
	dclist::test();
	slist sl;
	slist::test();
	//slist::test2();
	system("pause");
	return 0;
}
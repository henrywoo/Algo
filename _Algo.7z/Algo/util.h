#ifndef _ALGO_UTIL_
#define _ALGO_UTIL_
#pragma once

// template<typename T>
// void swap_(T& x, T& y){
// 	T tmp;
// 	tmp=x;
// 	x=y;
// 	y=tmp;
// }




#endif // _ALGO_UTIL_